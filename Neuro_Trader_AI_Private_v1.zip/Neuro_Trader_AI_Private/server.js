import express from "express";
import helmet from "helmet";
import cookieParser from "cookie-parser";
import rateLimit from "express-rate-limit";
import Database from "better-sqlite3";
import argon2 from "argon2";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { TradingEngine } from "./engine.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.join(__dirname, "data");
fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new Database(path.join(DATA_DIR, "neurotrader.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
db.exec(`
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS secrets (name TEXT PRIMARY KEY, iv TEXT NOT NULL, tag TEXT NOT NULL, ciphertext TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, csrf TEXT NOT NULL, expires_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS trades (id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT NOT NULL, side TEXT NOT NULL, qty REAL NOT NULL, price REAL NOT NULL, notional REAL NOT NULL, pnl REAL DEFAULT 0, mode TEXT NOT NULL, reason TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS positions (symbol TEXT PRIMARY KEY, qty REAL NOT NULL, entry_price REAL NOT NULL, invested REAL NOT NULL, stop_loss REAL NOT NULL, take_profit REAL NOT NULL, source TEXT NOT NULL, opened_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY AUTOINCREMENT, level TEXT NOT NULL, message TEXT NOT NULL, created_at TEXT NOT NULL);
`);
const getSetting = db.prepare("SELECT value FROM settings WHERE key=?");
const setSetting = db.prepare("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value");
const app = express();
app.disable("x-powered-by");
app.set("trust proxy", 1);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:"],
      connectSrc: ["'self'", "https://api.binance.com", "https://generativelanguage.googleapis.com", "https://api.openai.com"],
      frameAncestors: ["'none'"]
    }
  },
  crossOriginEmbedderPolicy: false
}));
app.use(express.json({ limit: "32kb" }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public"), { index: false }));

const ENCRYPTION_KEY = process.env.APP_ENCRYPTION_KEY || "";
const validEncryptionKey = /^[a-f0-9]{64}$/i.test(ENCRYPTION_KEY);
function encryptSecret(value) {
  if (!validEncryptionKey) throw new Error("APP_ENCRYPTION_KEY is not configured. Follow README setup.");
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", Buffer.from(ENCRYPTION_KEY, "hex"), iv);
  const ciphertext = Buffer.concat([cipher.update(value, "utf8"), cipher.final()]);
  return { iv: iv.toString("hex"), tag: cipher.getAuthTag().toString("hex"), ciphertext: ciphertext.toString("hex") };
}
function decryptSecret(row) {
  const decipher = crypto.createDecipheriv("aes-256-gcm", Buffer.from(ENCRYPTION_KEY, "hex"), Buffer.from(row.iv, "hex"));
  decipher.setAuthTag(Buffer.from(row.tag, "hex"));
  return Buffer.concat([decipher.update(Buffer.from(row.ciphertext, "hex")), decipher.final()]).toString("utf8");
}
function saveSecret(name, value) {
  if (!value) { db.prepare("DELETE FROM secrets WHERE name=?").run(name); return; }
  const enc = encryptSecret(value);
  db.prepare("INSERT INTO secrets(name,iv,tag,ciphertext,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(name) DO UPDATE SET iv=excluded.iv,tag=excluded.tag,ciphertext=excluded.ciphertext,updated_at=excluded.updated_at")
    .run(name, enc.iv, enc.tag, enc.ciphertext, new Date().toISOString());
}
function readSecret(name) {
  const row = db.prepare("SELECT * FROM secrets WHERE name=?").get(name);
  return row ? decryptSecret(row) : "";
}
function event(level, message) {
  db.prepare("INSERT INTO events(level,message,created_at) VALUES(?,?,?)").run(level, String(message).slice(0, 500), new Date().toISOString());
}
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, standardHeaders: "draft-7", legacyHeaders: false });
const apiLimiter = rateLimit({ windowMs: 60 * 1000, limit: 120, standardHeaders: "draft-7", legacyHeaders: false });

function sessionFromReq(req) {
  const token = req.cookies.nt_session;
  if (!token) return null;
  const hash = crypto.createHash("sha256").update(token).digest("hex");
  const row = db.prepare("SELECT * FROM sessions WHERE token_hash=? AND expires_at>?").get(hash, Date.now());
  return row ? { token, hash, csrf: row.csrf } : null;
}
function requireAuth(req, res, next) {
  const session = sessionFromReq(req);
  if (!session) return res.status(401).json({ error: "Login required" });
  req.session = session;
  next();
}
function requireCsrf(req, res, next) {
  if (["GET", "HEAD", "OPTIONS"].includes(req.method)) return next();
  const supplied = req.get("x-csrf-token");
  if (!req.session || !supplied || Buffer.byteLength(supplied) !== Buffer.byteLength(req.session.csrf) || !crypto.timingSafeEqual(Buffer.from(supplied), Buffer.from(req.session.csrf))) {
    return res.status(403).json({ error: "CSRF validation failed" });
  }
  next();
}
app.get("/", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.get("/api/status", (req, res) => {
  const setup = !!getSetting.get("password_hash");
  const session = sessionFromReq(req);
  res.json({ setup, authenticated: !!session, csrf: session?.csrf || null, realTradingEnabled: process.env.ENABLE_REAL_TRADING === "true" });
});
app.post("/api/setup", authLimiter, async (req, res) => {
  if (getSetting.get("password_hash")) return res.status(409).json({ error: "Already configured" });
  const password = String(req.body?.password || "");
  if (password.length < 14 || password.length > 256) return res.status(400).json({ error: "Master password must be 14–256 characters" });
  if (!validEncryptionKey) return res.status(500).json({ error: "Encryption key is missing. See README." });
  const hash = await argon2.hash(password, { type: argon2.argon2id, memoryCost: 65536, timeCost: 3, parallelism: 1 });
  setSetting.run("password_hash", hash);
  event("security", "Master password initialized");
  createSession(res);
  res.json({ ok: true });
});
function createSession(res) {
  const token = crypto.randomBytes(32).toString("base64url");
  const csrf = crypto.randomBytes(24).toString("base64url");
  const hash = crypto.createHash("sha256").update(token).digest("hex");
  const expires = Date.now() + 8 * 60 * 60 * 1000;
  db.prepare("INSERT INTO sessions(token_hash,csrf,expires_at) VALUES(?,?,?)").run(hash, csrf, expires);
  res.cookie("nt_session", token, { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "strict", maxAge: 8 * 60 * 60 * 1000, path: "/" });
  return csrf;
}
app.post("/api/login", authLimiter, async (req, res) => {
  const row = getSetting.get("password_hash");
  if (!row) return res.status(400).json({ error: "Set up master password first" });
  const password = String(req.body?.password || "");
  const ok = await argon2.verify(row.value, password).catch(() => false);
  if (!ok) { event("warning", "Failed login attempt"); return res.status(401).json({ error: "Incorrect password" }); }
  createSession(res);
  res.json({ ok: true });
});
app.post("/api/logout", requireAuth, requireCsrf, (req, res) => {
  db.prepare("DELETE FROM sessions WHERE token_hash=?").run(req.session.hash);
  res.clearCookie("nt_session", { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "strict", path: "/" });
  res.json({ ok: true });
});
app.use("/api", apiLimiter);
app.use("/api", requireAuth);
app.use("/api", requireCsrf);

const engine = new TradingEngine({ db, getSecret: readSecret, event });
app.get("/api/dashboard", (req, res) => res.json(engine.snapshot()));
app.get("/api/settings", (req, res) => {
  res.json({
    geminiConfigured: !!readSecret("gemini"),
    openaiConfigured: !!readSecret("openai"),
    binanceConfigured: !!readSecret("binance_key") && !!readSecret("binance_secret"),
    settings: engine.getConfig()
  });
});
app.put("/api/settings", (req, res) => {
  const allowed = ["budget", "tradeSize", "stopLossPct", "takeProfitPct", "dailyLossLimit", "maxPositions", "cooldownMinutes", "aiEnabled", "selectedSymbols", "mode"];
  const cfg = engine.getConfig();
  for (const k of allowed) if (req.body && Object.hasOwn(req.body, k)) cfg[k] = req.body[k];
  if (cfg.mode !== "DEMO") return res.status(403).json({ error: "This release supports DEMO mode only. Real trading is intentionally locked." });
  try { engine.updateConfig(cfg); res.json({ ok: true, settings: engine.getConfig() }); }
  catch (e) { res.status(400).json({ error: e.message }); }
});
app.put("/api/vault", (req, res) => {
  const fields = ["gemini", "openai", "binance_key", "binance_secret"];
  try {
    for (const field of fields) {
      if (Object.hasOwn(req.body || {}, field)) saveSecret(field, String(req.body[field] || "").trim());
    }
    event("security", "API vault updated");
    res.json({ ok: true, configured: {
      gemini: !!readSecret("gemini"), openai: !!readSecret("openai"),
      binance: !!readSecret("binance_key") && !!readSecret("binance_secret")
    }});
  } catch (e) { res.status(500).json({ error: e.message }); }
});
app.post("/api/vault/test-gemini", async (req, res) => {
  const key = readSecret("gemini");
  if (!key) return res.status(400).json({ error: "Gemini key not saved" });
  try {
    const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${encodeURIComponent(key)}`, {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ contents: [{ parts: [{ text: "Reply with exactly: CONNECTION_OK" }] }] }),
      signal: AbortSignal.timeout(12000)
    });
    if (!r.ok) throw new Error(`Provider returned HTTP ${r.status}`);
    const j = await r.json();
    res.json({ ok: true, message: j.candidates?.[0]?.content?.parts?.[0]?.text || "Connected" });
  } catch (e) { res.status(502).json({ error: e.message }); }
});
app.post("/api/trade/buy", (req, res) => {
  try { res.json(engine.manualBuy(String(req.body.symbol || ""))); }
  catch (e) { res.status(400).json({ error: e.message }); }
});
app.post("/api/trade/sell", async (req, res) => {
  try { res.json(await engine.manualSell(String(req.body.symbol || ""))); }
  catch (e) { res.status(400).json({ error: e.message }); }
});
app.post("/api/ai/start", (req, res) => {
  try { engine.startAI(); res.json({ ok: true }); } catch (e) { res.status(400).json({ error: e.message }); }
});
app.post("/api/ai/pause", (req, res) => { engine.pauseAI(); res.json({ ok: true }); });
app.post("/api/emergency-stop", (req, res) => { engine.emergencyStop(); res.json({ ok: true }); });
app.get("/api/events", (req, res) => {
  const rows = db.prepare("SELECT level,message,created_at FROM events ORDER BY id DESC LIMIT 50").all();
  res.json(rows);
});
app.use((err, req, res, next) => {
  event("error", err.message || "Unhandled error");
  res.status(500).json({ error: "Internal server error" });
});

const host = process.env.HOST || "127.0.0.1";
const port = Number(process.env.PORT || 3000);
app.listen(port, host, () => {
  console.log(`Neuro Trader AI listening at http://${host}:${port}`);
  if (!validEncryptionKey) console.warn("WARNING: APP_ENCRYPTION_KEY missing/invalid; API vault disabled until configured.");
  engine.start();
});
process.on("SIGINT", () => { engine.stop(); db.close(); process.exit(0); });
process.on("SIGTERM", () => { engine.stop(); db.close(); process.exit(0); });