const SYMBOLS = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT", "XRPUSDT"];
const DEFAULTS = {
  mode: "DEMO", budget: 500, tradeSize: 50, stopLossPct: 2.0, takeProfitPct: 3.0,
  dailyLossLimit: 20, maxPositions: 2, cooldownMinutes: 15,
  aiEnabled: false, selectedSymbols: ["BTCUSDT", "ETHUSDT", "SOLUSDT"]
};
const sleep = ms => new Promise(r => setTimeout(r, ms));

export class TradingEngine {
  constructor({ db, getSecret, event }) {
    this.db = db; this.getSecret = getSecret; this.event = event;
    this.running = false; this.busy = false; this.timer = null; this.lastEntry = {};
    this.config = { ...DEFAULTS };
    const saved = db.prepare("SELECT value FROM settings WHERE key='trade_config'").get();
    if (saved) { try { this.config = { ...DEFAULTS, ...JSON.parse(saved.value) }; } catch {} }
    this.config.mode = "DEMO";
    this.market = {};
  }
  getConfig() { return structuredClone(this.config); }
  updateConfig(c) {
    const n = { ...DEFAULTS, ...c };
    const num = (k, min, max) => { n[k] = Number(n[k]); if (!Number.isFinite(n[k]) || n[k] < min || n[k] > max) throw new Error(`Invalid ${k}`); };
    num("budget", 10, 1000000); num("tradeSize", 10, 100000); num("stopLossPct", 0.2, 20);
    num("takeProfitPct", 0.2, 100); num("dailyLossLimit", 1, 100000); num("maxPositions", 1, 5);
    num("cooldownMinutes", 1, 1440);
    if (n.mode !== "DEMO") throw new Error("Only DEMO mode is available");
    if (!Array.isArray(n.selectedSymbols) || n.selectedSymbols.some(s => !SYMBOLS.includes(s))) throw new Error("Unsupported symbol selection");
    n.aiEnabled = !!n.aiEnabled;
    this.config = n;
    this.db.prepare("INSERT INTO settings(key,value) VALUES('trade_config',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").run(JSON.stringify(n));
    this.event("info", "Trading configuration updated");
  }
  async fetchMarket(symbol) {
    const url = `https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=15m&limit=3`;
    const r = await fetch(url, { signal: AbortSignal.timeout(10000) });
    if (!r.ok) throw new Error(`Market API HTTP ${r.status}`);
    const d = await r.json();
    if (!Array.isArray(d) || d.length < 3) throw new Error("Insufficient candle data");
    // Use the last fully closed candle, not the currently-forming candle.
    const candle = d[d.length - 2];
    const market = { symbol, open: +candle[1], high: +candle[2], low: +candle[3], close: +candle[4], volume: +candle[5], candleCloseTime: candle[6], fetchedAt: Date.now() };
    if (!Number.isFinite(market.close) || market.close <= 0 || Date.now() - market.candleCloseTime > 35 * 60 * 1000) throw new Error("Stale/invalid market data");
    this.market[symbol] = market;
    return market;
  }
  analyze(c) {
    const body = Math.abs(c.close - c.open);
    const upper = c.high - Math.max(c.open, c.close);
    const lower = Math.min(c.open, c.close) - c.low;
    if (lower > Math.max(body * 2, c.close * 0.0005) && upper < Math.max(body * 0.8, c.close * 0.0002) && c.close >= c.open) return "BUY";
    if (upper > Math.max(body * 2, c.close * 0.0005) && lower < Math.max(body * 0.8, c.close * 0.0002)) return "SELL";
    return "HOLD";
  }
  async aiDecision(c, localSignal) {
    const key = this.getSecret("gemini");
    if (!key) return localSignal;
    try {
      const prompt = `You are a cautious market signal classifier, not an execution authority. Symbol ${c.symbol}; last closed 15m candle O:${c.open} H:${c.high} L:${c.low} C:${c.close} volume:${c.volume}. Local signal:${localSignal}. Reply only BUY, SELL, or HOLD. Prefer HOLD when uncertain.`;
      const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${encodeURIComponent(key)}`, {
        method: "POST", headers: { "content-type": "application/json" },
        body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { temperature: 0, maxOutputTokens: 5 } }),
        signal: AbortSignal.timeout(10000)
      });
      if (!r.ok) throw new Error(`Gemini HTTP ${r.status}`);
      const j = await r.json();
      const answer = (j.candidates?.[0]?.content?.parts?.[0]?.text || "").trim().toUpperCase();
      if (["BUY", "SELL", "HOLD"].includes(answer)) return answer;
      return "HOLD";
    } catch (e) { this.event("warning", `AI provider unavailable; safe HOLD fallback (${e.message})`); return "HOLD"; }
  }
  getPositions() { return this.db.prepare("SELECT * FROM positions ORDER BY opened_at DESC").all(); }
  getDailyPnl() {
    const since = new Date(); since.setHours(0,0,0,0);
    const row = this.db.prepare("SELECT COALESCE(SUM(pnl),0) AS pnl FROM trades WHERE side='SELL' AND created_at>=?").get(since.toISOString());
    return row.pnl || 0;
  }
  getSnapshot() {
    const positions = this.getPositions().map(p => {
      const m = this.market[p.symbol];
      const price = m?.close || p.entry_price;
      const floating = (price - p.entry_price) * p.qty;
      return { ...p, price, floatingPnl: floating, floatingPct: p.invested ? floating / p.invested * 100 : 0 };
    });
    const stats = this.db.prepare("SELECT COALESCE(SUM(CASE WHEN pnl>0 THEN pnl ELSE 0 END),0) profit, COALESCE(SUM(CASE WHEN pnl<0 THEN -pnl ELSE 0 END),0) loss FROM trades WHERE side='SELL'").get();
    return { mode: "DEMO", running: this.running, config: this.getConfig(), positions, market: this.market, stats, dailyPnl: this.getDailyPnl(), events: this.db.prepare("SELECT level,message,created_at FROM events ORDER BY id DESC LIMIT 8").all() };
  }
  snapshot() { return this.getSnapshot(); }
  startAI() { this.config.aiEnabled = true; this.persistConfig(); this.event("info", "AI auto-trading enabled in DEMO mode"); }
  pauseAI() { this.config.aiEnabled = false; this.persistConfig(); this.event("info", "AI paused; open positions remain managed"); }
  emergencyStop() { this.config.aiEnabled = false; this.persistConfig(); this.event("critical", "Emergency stop: new entries disabled. Open demo positions remain visible."); }
  persistConfig() {
    this.db.prepare("INSERT INTO settings(key,value) VALUES('trade_config',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").run(JSON.stringify(this.config));
  }
  manualBuy(symbol) {
    if (!SYMBOLS.includes(symbol)) throw new Error("Unsupported market");
    if (this.config.mode !== "DEMO") throw new Error("Only demo mode available");
    if (this.db.prepare("SELECT 1 FROM positions WHERE symbol=?").get(symbol)) throw new Error("Position already open");
    const c = this.market[symbol];
    if (!c || Date.now() - c.fetchedAt > 60000) throw new Error("Fresh market price unavailable; wait for refresh");
    return this.openPosition(symbol, c.close, "MANUAL");
  }
  async manualSell(symbol) {
    if (!SYMBOLS.includes(symbol)) throw new Error("Unsupported market");
    const p = this.db.prepare("SELECT * FROM positions WHERE symbol=?").get(symbol);
    if (!p) throw new Error("No open position");
    const c = await this.fetchMarket(symbol);
    return this.closePosition(p, c.close, "MANUAL SELL");
  }
  openPosition(symbol, price, source) {
    const cfg = this.config;
    const open = this.getPositions();
    const invested = Math.min(cfg.tradeSize, cfg.budget - open.reduce((s,p)=>s+p.invested,0));
    if (open.length >= cfg.maxPositions) throw new Error("Maximum open positions reached");
    if (invested < 10) throw new Error("Configured budget exhausted");
    if (-this.getDailyPnl() >= cfg.dailyLossLimit) throw new Error("Daily loss limit reached");
    const qty = invested / price;
    const now = new Date().toISOString();
    this.db.prepare("INSERT INTO positions(symbol,qty,entry_price,invested,stop_loss,take_profit,source,opened_at) VALUES(?,?,?,?,?,?,?,?)")
      .run(symbol, qty, price, invested, cfg.stopLossPct, cfg.takeProfitPct, source, now);
    this.db.prepare("INSERT INTO trades(symbol,side,qty,price,notional,pnl,mode,reason,created_at) VALUES(?,?,?,?,?,?,?,?,?)")
      .run(symbol, "BUY", qty, price, invested, 0, "DEMO", source, now);
    this.lastEntry[symbol] = Date.now();
    this.event("trade", `DEMO BUY ${symbol} @ ${price.toFixed(4)}; amount $${invested.toFixed(2)}`);
    return { ok: true };
  }
  closePosition(p, price, reason) {
    const pnl = (price - p.entry_price) * p.qty;
    const now = new Date().toISOString();
    this.db.prepare("DELETE FROM positions WHERE symbol=?").run(p.symbol);
    this.db.prepare("INSERT INTO trades(symbol,side,qty,price,notional,pnl,mode,reason,created_at) VALUES(?,?,?,?,?,?,?,?,?)")
      .run(p.symbol, "SELL", p.qty, price, p.qty * price, pnl, "DEMO", reason, now);
    this.event("trade", `DEMO SELL ${p.symbol} @ ${price.toFixed(4)}; P&L $${pnl.toFixed(2)} (${reason})`);
    return { ok: true, pnl };
  }
  async tick() {
    if (this.busy) return;
    this.busy = true;
    try {
      for (const symbol of SYMBOLS) {
        try { await this.fetchMarket(symbol); } catch (e) { this.event("warning", `${symbol} market data unavailable: ${e.message}`); }
      }
      for (const p of this.getPositions()) {
        const c = this.market[p.symbol];
        if (!c || Date.now() - c.fetchedAt > 60000) continue;
        const pct = (c.close - p.entry_price) / p.entry_price * 100;
        if (pct <= -p.stop_loss) this.closePosition(p, c.close, "DEMO STOP LOSS");
        else if (pct >= p.take_profit) this.closePosition(p, c.close, "DEMO TAKE PROFIT");
      }
      if (!this.config.aiEnabled) return;
      if (-this.getDailyPnl() >= this.config.dailyLossLimit) { this.pauseAI(); this.event("critical", "Daily loss cap reached; AI paused"); return; }
      for (const symbol of this.config.selectedSymbols) {
        if (this.getPositions().length >= this.config.maxPositions) break;
        if (this.db.prepare("SELECT 1 FROM positions WHERE symbol=?").get(symbol)) continue;
        if (Date.now() - (this.lastEntry[symbol] || 0) < this.config.cooldownMinutes * 60000) continue;
        const c = this.market[symbol];
        if (!c || Date.now() - c.fetchedAt > 60000) continue;
        const local = this.analyze(c);
        // Gemini may only confirm a local BUY. It cannot promote HOLD into BUY.
        const decision = local === "BUY" ? await this.aiDecision(c, local) : "HOLD";
        if (local === "BUY" && decision === "BUY") {
          try { this.openPosition(symbol, c.close, "AI CONFIRMED DEMO"); } catch (e) { this.event("warning", e.message); }
        }
        await sleep(150);
      }
    } finally { this.busy = false; }
  }
  start() {
    if (this.running) return;
    this.running = true;
    this.tick().catch(e => this.event("error", e.message));
    this.timer = setInterval(() => this.tick().catch(e => this.event("error", e.message)), 15000);
  }
  stop() { this.running = false; if (this.timer) clearInterval(this.timer); }
}