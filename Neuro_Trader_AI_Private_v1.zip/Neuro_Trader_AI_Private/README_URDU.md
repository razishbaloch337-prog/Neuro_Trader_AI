# Neuro Trader AI — Private Build 1.0

یہ آپ کے فراہم کردہ `index (14).html` کے بنیادی ڈیش بورڈ خیال کو ایک الگ، محفوظ Node.js backend اور database کے ساتھ دوبارہ منظم کرتا ہے۔ یہ عام static HTML صفحہ نہیں ہے۔

## اس build میں کیا کام کرتا ہے؟

- پہلی بار ماسٹر پاس ورڈ سیٹ اپ؛ Argon2id password hashing۔
- Session cookie: HttpOnly، SameSite=Strict؛ API write requests پر CSRF token۔
- API Vault: Gemini، OpenAI backup، Binance key/secret کو سرور پر AES-256-GCM encryption کے ساتھ محفوظ کرتا ہے۔
- API keys browser `localStorage` میں محفوظ نہیں ہوتیں اور دوبارہ plaintext میں UI کو واپس نہیں بھیجی جاتیں۔
- Gemini connection test اور Gemini market signal confirmation۔
- Binance public 15-minute candle data؛ صرف بند (closed) candle سے local signal۔
- Demo BUY/SELL، persisted positions/trades، floating P&L، risk limits، daily loss cap، max positions، cooldown۔
- AI صرف مقامی BUY signal کی تصدیق کر سکتا ہے؛ AI اکیلا HOLD کو BUY میں تبدیل نہیں کر سکتا۔
- AI/provider/market data failure کی صورت میں نئی AI entry نہیں کھولی جاتی۔
- Emergency Stop نئے AI entries کو بند کرتا ہے؛ کھلی demo position ریکارڈ میں رہتی ہے۔

## اہم اور واضح حد

**یہ release حقیقی رقم سے Binance پر آرڈر نہیں بھیجتی۔ Real trading جان بوجھ کر بند ہے۔** Binance credentials صرف encrypted vault میں محفوظ ہو سکتے ہیں؛ اس build میں ان سے live order execution نہیں ہوتی۔ وجہ یہ ہے کہ real-money execution کے لیے exchange-side protective orders، order reconciliation، idempotency، fee/slippage handling، testnet validation اور offline VPS failure behavior کی مزید مکمل جانچ ضروری ہے۔ Demo P&L حقیقی منافع کا ثبوت نہیں۔

OpenAI key اس build میں محفوظ ہو سکتی ہے، مگر OpenAI failover decision adapter ابھی منسلک نہیں؛ Gemini ناکام ہونے پر engine محفوظ HOLD اختیار کرتا ہے۔

## تنصیب

ضروریات: Node.js 20 یا اس سے نیا، npm۔

1. ZIP extract کریں۔
2. Terminal میں project folder کھولیں۔
3. `.env.example` کی copy بنا کر `.env` نام دیں۔
4. `APP_ENCRYPTION_KEY` کے لیے 64 hexadecimal characters کی نئی key بنائیں:

   Linux/macOS:
   ```bash
   openssl rand -hex 32
   ```

   Windows PowerShell (Node.js دستیاب ہو):
   ```powershell
   node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
   ```

5. اس key کو `.env` میں `APP_ENCRYPTION_KEY=` کے بعد درج کریں۔ key کو محفوظ offline جگہ پر backup رکھیں؛ key گم ہو گئی تو encrypted API keys decrypt نہیں ہو سکیں گی۔
6. Install اور run:
   ```bash
   npm install
   npm start
   ```
7. اسی کمپیوٹر پر `http://127.0.0.1:3000` کھولیں۔ پہلی بار 14+ حروف کا منفرد master password بنائیں۔

## VPS / 24×7

یہ app تبھی مسلسل چل سکتی ہے جب Node.js process کسی always-on computer/VPS پر چل رہا ہو۔ ابھی `.env` میں HOST کو `127.0.0.1` رکھیں اور remote access کے لیے اسے براہِ راست public نہ کریں۔ پہلے HTTPS reverse proxy، firewall، OS updates، restricted SSH، backup اور monitoring لگائیں۔ Secure deployment کے بغیر public internet پر expose نہ کریں۔

## Data اور backup

`data/neurotrader.sqlite` میں settings، encrypted secrets، positions، trades اور audit events محفوظ ہیں۔ باقاعدگی سے بند application کی database backup بنائیں اور encryption key الگ محفوظ رکھیں۔ Database یا `.env` کسی کو نہ بھیجیں۔

## حفاظتی حدود

- Master password کم از کم 14 حروف۔
- Login rate limit، Helmet security headers، CSP، Argon2id، AES-256-GCM، CSRF، HttpOnly cookie۔
- Single-user local instance؛ ابھی 2FA، hardware key، external KMS، persistent distributed session store، automated encrypted backup، independent penetration test شامل نہیں۔
- API keys کے لیے Binance پر withdrawal permission کبھی enable نہ کریں؛ بہتر ہے الگ کم اختیارات والی test key اور IP allowlist استعمال کریں۔
- کسی بھی trading strategy میں نقصان کا امکان ہے؛ کوئی profit guarantee نہیں۔

## اگلا حقیقی-trading مرحلہ

اسے real trading میں تبدیل کرنے سے پہلے Binance Spot Testnet، signed order adapter، exchange-side OCO/stop protection، order idempotency، reconnect/reconciliation، fee/slippage accounting، database migrations، 2FA اور security review مکمل کرنا ہوگا۔ موجودہ build کو live-money bot نہ سمجھیں۔